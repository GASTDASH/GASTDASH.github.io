﻿RU
Чтобы запустить игру без музыки нажмите на экране ожидания клавишу "M"
Поменять язык -> Settings -> Нажать "L"



EN
To start the game without music, press the "M" key on the standby screen
Change language -> Настройки -> Press "L"